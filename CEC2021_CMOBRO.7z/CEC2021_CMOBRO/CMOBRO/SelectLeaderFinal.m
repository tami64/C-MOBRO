function leader=SelectLeaderFinal(rep,beta,soldier)
if(numel(rep)==0)
    isFeasible = 0;
    for i=1:numel(soldier)
        if(soldier(i).CV == 0)
            feasibleIndex = i;
            isFeasible = 1;
            break;
        end
    end
    if(isFeasible == 1)%select the best feasible
        leader= soldier(feasibleIndex);
    else
        smi=randi([1 numel(soldier)]);
        leader= soldier(smi);
    end
else
    % Grid Index of All Repository Members
    GI=[rep.GridIndex];
    
    % Occupied Cells
    OC=unique(GI);
    
    % Number of Particles in Occupied Cells
    N=zeros(size(OC));
    for k=1:numel(OC)
        N(k)=numel(find(GI==OC(k)));
    end
    
    % Selection Probabilities
    P=exp(-beta*N);
    P=P/sum(P);
    
    % Selected Cell Index
    sci=RouletteWheelSelection(P);
    
    % Selected Cell
    sc=OC(sci);
    
    % Selected Cell Members id in Rep
    SCM=find(GI==sc);
    
    %
    % Selected feasible member index from the selected grid 
    if(numel(SCM)> 1)
        isFeasible = 0;
        for i=1:length(SCM)
            repId = SCM(i);
            if(rep(repId).CV == 0)
                smi = repId;
                isFeasible = 1;
                if(rand()>0.5)
                    break;
                end
            end
        end
        
        if(isFeasible == 0)
            minCV = +inf;
            minCVIndex = 0;
            for i=1:length(SCM)
                repId = SCM(i)
                if(rep(repId).CV < minCV)
                    minCVIndex = repId;
                    minCV = rep(repId).CV;
                    %break;
                end
            end
            smi = minCVIndex;
        end
        
    else
        smi = 1;
    end
    
    % Leader
    leader=rep(smi);
end

end