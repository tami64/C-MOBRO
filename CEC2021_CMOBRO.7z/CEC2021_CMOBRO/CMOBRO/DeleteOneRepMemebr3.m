function rep=DeleteOneRepMemebr3(rep,gamma)

    % Grid Index of All Repository Members
    GI=[rep.GridIndex];
    
    % Occupied Cells
    OC=unique(GI);
    
    % Number of Particles in Occupied Cells
    N=zeros(size(OC));
    for k=1:numel(OC)
         N(k)=numel(find(GI==OC(k)));
%          N(k)=  find(GI==OC(k));
    end
    
    
    % Selection Probabilities
    P=exp(gamma*N);
    P=P/sum(P);
    
    % Selected Cell Index
    sci=RouletteWheelSelection(P);
    
    % Selected Cell
    sc=OC(sci);
    
    % Selected Cell Members
    SCM=find(GI==sc);
    
    % Selected member index from the selected grid that has higher CV value 
    if(numel(SCM)> 1)        
            maxCV = -inf;
            maxCVIndex = 0;
            for i=1:length(SCM)
                repId = SCM(i);
                if(rep(repId).CV >= maxCV)
                    maxCVIndex = repId;
                    maxCV = rep(repId).CV;
                    %break;
                end
            end
            smi = maxCVIndex;     
    else
        smi = 1;
    end
      
    % Delete Selected Member
    rep(smi)=[];

end