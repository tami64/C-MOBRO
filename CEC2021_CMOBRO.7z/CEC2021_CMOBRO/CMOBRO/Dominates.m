function b=Dominates(x,y)  
    b=0;     
    if x.CV == 0 && y.CV ~= 0
        b = 1;
    end    
   
    if x.CV ~= 0 && y.CV ~= 0
        if(x.CV <= y.CV)
            b = 1;        
        end
    end
    
    if  x.CV == 0 && y.CV == 0
       b=all(x.Cost<=y.Cost) && any(x.Cost<y.Cost); 
    end    
%     b=all(x.Cost<=y.Cost) && any(x.Cost<y.Cost) && x.CV<=y.CV; 
end