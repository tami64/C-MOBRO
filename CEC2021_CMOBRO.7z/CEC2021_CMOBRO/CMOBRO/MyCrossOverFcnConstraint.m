function [Off1 x] = MyCrossOverFcnConstraint(Parent1,Parent2,Dim,Method,Eval,par)
%[soldier(dam).Position soldier(dam).vel] = MyCrossOverFcn(soldier(dam),flag,Dim,CrossType,Eval);

switch Method
    case 1
        Off1 = Parent1.Position+rand(Dim,1) .*(Parent2.Position-Parent1.Position);
        x = 0;
        temp =  Eval(Off1);
        tmpSoldier.Position = Off1;
        tmpSoldier.Cost = temp.f;
        tmpSoldier.g = temp.g;
        tmpSoldier.h = temp.h;
        tmpSoldier.CV = Get_CV(par,tmpSoldier);
        tmpSoldier.vel = x;
        
        if(Parent1.CV == 0 && tmpSoldier.CV ~= 0)
            Off1 = Parent1.Position;
            x = Parent1.vel;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV == 0)
            Off1 = tmpSoldier.Position;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV ~= 0)            
            if(tmpSoldier.CV <= Parent1.CV)
                Off1 = tmpSoldier.Position;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
        end
        
        if(Parent1.CV == 0 && tmpSoldier.CV == 0)
            if Dominates(Parent1,tmpSoldier)
                Off1 = Parent1.Position;
                x = Parent1.vel;
            else%if Dominates(Parent1,tmpSoldier)
                Off1 = tmpSoldier.Position;
                x = tmpSoldier.vel;
            end            
        end

    case 2
        Off1 = rand(Dim,1) .* (max([Parent1.Position,Parent2.Position],[],2) - min([Parent1.Position,Parent2.Position],[],2)) + min([Parent1.Position,Parent2.Position],[],2);
        x = 0;
        temp =  Eval(Off1);
        tmpSoldier.Position = Off1;
        tmpSoldier.Cost = temp.f;
        tmpSoldier.g = temp.g;
        tmpSoldier.h = temp.h;
        tmpSoldier.CV = Get_CV(par,tmpSoldier);
        tmpSoldier.vel = x;
        
        if(Parent1.CV == 0 && tmpSoldier.CV ~= 0)
            Off1 = Parent1.Position;
            x = Parent1.vel;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV == 0)
            Off1 = tmpSoldier.Position;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV ~= 0)            
            if(tmpSoldier.CV <= Parent1.CV)
                Off1 = tmpSoldier.Position;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
        end
        
        if(Parent1.CV == 0 && tmpSoldier.CV == 0)
            if Dominates(Parent1,tmpSoldier)
                Off1 = Parent1.Position;
                x = Parent1.vel;
            else%if Dominates(Parent1,tmpSoldier)
                Off1 = tmpSoldier.Position;
                x = tmpSoldier.vel;
            end            
        end
    case 3
        Beta1 = rand;
        Off1 = Beta1*Parent1.Position + (1-Beta1)*Parent2.Position;
        x = 0;
                temp =  Eval(Off1);
        tmpSoldier.Position = Off1;
        tmpSoldier.Cost = temp.f;
        tmpSoldier.g = temp.g;
        tmpSoldier.h = temp.h;
        tmpSoldier.CV = Get_CV(par,tmpSoldier);
        tmpSoldier.vel = x;
        
        if(Parent1.CV == 0 && tmpSoldier.CV ~= 0)
            Off1 = Parent1.Position;
            x = Parent1.vel;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV == 0)
            Off1 = tmpSoldier.Position;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV ~= 0)            
            if(tmpSoldier.CV <= Parent1.CV)
                Off1 = tmpSoldier.Position;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
        end
        
        if(Parent1.CV == 0 && tmpSoldier.CV == 0)
            if Dominates(Parent1,tmpSoldier)
                Off1 = Parent1.Position;
                x = Parent1.vel;
            else%if Dominates(Parent1,tmpSoldier)
                Off1 = tmpSoldier.Position;
                x = tmpSoldier.vel;
            end            
        end
    case 4
        R1 = rand(Dim,1);
        R2 = rand(Dim,1);
        x =   R1 .* Parent2.Position + R2 .* (Parent1.vel-Parent1.Position);
        Off1 = Parent1.Position + x;
        
        
        temp =  Eval(Off1);
        tmpSoldier.Position = Off1;
        tmpSoldier.Cost = temp.f;
        tmpSoldier.g = temp.g;
        tmpSoldier.h = temp.h;
        tmpSoldier.CV = Get_CV(par,tmpSoldier);
        tmpSoldier.vel = x;
        
        if(Parent1.CV == 0 && tmpSoldier.CV ~= 0)
            Off1 = Parent1.Position;
            x = Parent1.vel;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV == 0)
            Off1 = tmpSoldier.Position;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV ~= 0)            
            if(tmpSoldier.CV <= Parent1.CV)
                Off1 = tmpSoldier.Position;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
        end
        
        if(Parent1.CV == 0 && tmpSoldier.CV == 0)
            b=all(tmpSoldier.Cost<=Parent1.Cost) && any(tmpSoldier.Cost<Parent1.Cost);
            if b == 1
              Off1 = tmpSoldier.Position;
              x = tmpSoldier.vel;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
            % if Dominates(Parent1,tmpSoldier)
            %     Off1 = Parent1.Position;
            %     x = Parent1.vel;
            % else%if Dominates(Parent1,tmpSoldier)
            %     Off1 = tmpSoldier.Position;
            %     x = tmpSoldier.vel;
            % end            
        end

    case 5                      
        R1 = rand(Dim,1);
        R2 = rand(Dim,1);
        x =   R1 .* Parent2.Position + R2 .* (Parent1.vel-Parent1.Position);
        alpha = rand(size(Parent1.Position));    
        y1 = alpha.*Parent1.Position+(1-alpha).*Parent2.Position;
        y2 = alpha.*Parent2.Position+(1-alpha).*Parent1.Position;
        
        
        temp =  Eval(y1);
        tmpSoldier1.Position = y1;
        tmpSoldier1.Cost = temp.f;
        tmpSoldier1.g = temp.g;
        tmpSoldier1.h = temp.h;
        tmpSoldier1.CV = Get_CV(par,tmpSoldier1);
        tmpSoldier1.vel = x;



        temp =  Eval(y2);
        tmpSoldier2.Position = y2;
        tmpSoldier2.Cost = temp.f;
        tmpSoldier2.g = temp.g;
        tmpSoldier2.h = temp.h;
        tmpSoldier2.CV = Get_CV(par,tmpSoldier2);
        tmpSoldier2.vel = x;
        
        if(Dominates(tmpSoldier1,tmpSoldier2) == 1)
           tmpSoldier = tmpSoldier1; 
        else
            tmpSoldier = tmpSoldier2; 
        end


        
        if(Parent1.CV == 0 && tmpSoldier.CV ~= 0)
            Off1 = Parent1.Position;
            x = Parent1.vel;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV == 0)
            Off1 = tmpSoldier.Position;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV ~= 0)            
            if(tmpSoldier.CV <= Parent1.CV)
                Off1 = tmpSoldier.Position;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
        end
        
        if(Parent1.CV == 0 && tmpSoldier.CV == 0)
            if Dominates(Parent1,tmpSoldier)
                Off1 = Parent1.Position;
                x = Parent1.vel;
            else%if Dominates(Parent1,tmpSoldier)
                Off1 = tmpSoldier.Position;
                x = tmpSoldier.vel;
            end            
        end 
    case 6
        R1 = rand(Dim,1);
        R2 = rand(Dim,1);
        x =   R1 .* Parent2.Position + R2 .* (Parent1.vel-Parent1.Position);
        Off1 = Parent1.Position + x;
        
        
        temp =  Eval(Off1);
        tmpSoldier.Position = Off1;
        tmpSoldier.Cost = temp.f;
        tmpSoldier.g = temp.g;
        tmpSoldier.h = temp.h;
        tmpSoldier.CV = Get_CV(par,tmpSoldier);
        tmpSoldier.vel = x;
        
        if(Parent1.CV == 0 && tmpSoldier.CV ~= 0)
            Off1 = Parent1.Position;
            x = Parent1.vel;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV == 0)
            Off1 = tmpSoldier.Position;
        end
        
        if(Parent1.CV ~= 0 && tmpSoldier.CV ~= 0)            
            if(tmpSoldier.CV <= Parent1.CV)
                Off1 = tmpSoldier.Position;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
        end
        
        if(Parent1.CV == 0 && tmpSoldier.CV == 0)
            r=rand;
            if r <= 0.5
                Off1 = tmpSoldier.Position;
                x = tmpSoldier.vel;
            else
                Off1 = Parent1.Position;
                x = Parent1.vel;
            end
            % if Dominates(Parent1,tmpSoldier)
            %     Off1 = Parent1.Position;
            %     x = Parent1.vel;
            % else%if Dominates(Parent1,tmpSoldier)
            %     Off1 = tmpSoldier.Position;
            %     x = tmpSoldier.vel;
            % end            
        end        
      
end

