function [leader] = Force2Feasible(leader,rep,beta)
c = 0;
rep_ = rep;
while leader.CV~=0 && length(rep)>1
    if c>length(rep_)
        break;
    end
    if size(rep_,1)>0
        counter=0;
        for newi=1:size(rep_,1)
            if sum(leader.Position~=rep_(newi).Position)~=0
                counter=counter+1;
                rep2(counter,1)=rep_(newi);
            end
        end
        try
            if length(rep2)==0
                return
            end
            leader = SelectLeader(rep2,beta);
        catch
            a=0;
        end
        rep_ = rep2; 
        c = c + 1;
    end
end

end

