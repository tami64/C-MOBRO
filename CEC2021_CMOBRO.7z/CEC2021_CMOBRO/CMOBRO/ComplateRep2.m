function complated_Rep = ComplateRep2(rep,soldier,nRep,nGrid,alpha,gamma)

list1 = [soldier.Position];
list2 = [rep.Position];

% Initialize an empty array to store the indices of common cells
common_indices = [];
uncommon_indices = [];
complated_Rep = rep;

[nFun,numEle1] = size(list1);
[nFun,numEle2] = size(list2);

% Loop through the first list
for i = 1:numEle1
    % Loop through the second list
    for j = 1:numEle2
        % Check if the cells are equal
        if isequal(list1(:,i), list2(:,j))
            % If they are equal, store the index pair
            common_indices = [common_indices;i];
            break;
        end
    end
end

uncommon_indices = setdiff(linspace(1,length(soldier),length(soldier)), common_indices);  % Elements in A that are not in B
selectedCells = soldier(uncommon_indices);
%     % Determine Domination of New Resository Members
selectedCells = DetermineDomination4Complate(selectedCells);
complated_Rep = updateRep(complated_Rep,selectedCells);


%     % Keep only Non-Dminated Memebrs in the Repository
%rep2 = rep(~[rep.IsDominated]);

%rep = updateRep(rep,soldier);

%     % Determine Domination of New Resository Members
    complated_Rep = DetermineDomination(complated_Rep);
    %     % Keep only Non-Dminated Memebrs in the Repository
    rep2 = complated_Rep(~[complated_Rep.IsDominated]);

    %     if(numel(rep2) == 0)
    %         rep = [rep; flag];
    %         count = 0;
    %     end
    complated_Rep = rep2;
    % Update Grid
    Grid = CreateGrid(complated_Rep,nGrid,alpha);

    % Update Grid Indices
    for i=1:numel(complated_Rep)
        complated_Rep(i)=FindGridIndex(complated_Rep(i),Grid);
    end

    % Check if Repository is Full
    if numel(complated_Rep)>nRep

        Extra=numel(complated_Rep)-nRep;
        for e=1:Extra
            complated_Rep=DeleteOneRepMemebr3(complated_Rep,gamma);
        end
    end



end

