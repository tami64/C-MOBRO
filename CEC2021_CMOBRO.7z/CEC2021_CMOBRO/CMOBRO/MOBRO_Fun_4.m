
function [Res] = MOBRO_Fun_4(nPop,maxiter,Func,MaxNFE,MaxFault,CrossType,nGrid,alpha,beta,gamma,nRep,mu,par,showopen,mut)
Res = [];
tic
%cg_curve1 = zeros(1,maxiter);
global NFE
NFE = 0;

Shrink = ceil(log(maxiter)/log(10));
Step = round(maxiter/Shrink);
%%

%soldier.Fault  = zeros(1,nPop);
flag.Cost = inf;

empty_soldier.Position=[];
empty_soldier.Cost=[];
empty_soldier.Fault=[];
empty_soldier.IsDominated=[];
empty_soldier.GridIndex=[];
empty_soldier.GridSubIndex=[];
empty_soldier.vel = [];


soldier =repmat(empty_soldier,nPop,1);

Dim = par.n;
lb = par.xmin;
ub = par.xmax;
Eval = @(x) CEC2021_func(x,Func);

XMinMax = [lb',ub'];
ShrinkMinMax = XMinMax;


%% Initialization
xy = rand(Dim, nPop);

for i=1:nPop
    soldier(i).Position=xy(:,i).* (XMinMax(:, 2) - XMinMax(:, 1)) + XMinMax(:, 1);
    temp =  Eval(soldier(i).Position);
    soldier(i).Cost = temp.f;
    soldier(i).Fault  =  0;
    soldier(i).vel = zeros(Dim,1);
    soldier(i).g = temp.g;
    soldier(i).h = temp.h;
    soldier(i).CV = Get_CV(par,soldier(i));
end


%% Determine Domination
rep = [];
soldier = DetermineDomination(soldier);
rep = updateRep(rep,soldier);
Grid = CreateGrid(rep,nGrid,alpha);

for i=1:numel(rep)
    rep(i) = FindGridIndex(rep(i),Grid);
end

if(numel(rep) == 0)
    count = 0;
end

%% CMOBRO Main Loop
STDdim = zeros(Dim,1);
for iter = 1:maxiter

    flag = SelectLeaderFinal(rep,beta,soldier);
    flag.CV = Get_CV(par,flag);
    for i = 1:nPop
        vic_shrink = 0;
        leader = SelectLeaderFinal(rep,beta,soldier);
        %%
        leader = Force2Feasible(leader,rep,beta);
        %%
        if Dominates(leader,flag) % && leader.CV==0
            flag = leader;
        end

        [p q] =  edistance_n(i,soldier);
        for  k = 1:nPop
            if(Dominates(soldier(q(k)),soldier(i)))
                dam = i;
                Vic = q(k);
                break;
            elseif(Dominates(soldier(i),soldier(q(k))))
                dam = q(k);
                Vic = i;
                break;
            end
        end
        if(k == nPop)
            if(rand>0.5)
                dam = i ;
                Vic = q(1);
            else
                dam = q(1) ;
                Vic = i;
            end
        end

        soldier(dam).Fault= soldier(dam).Fault + 1;
        soldier(Vic).Fault = 0;

        if (soldier(dam).Fault < MaxFault)
            [soldier(dam).Position soldier(dam).vel] = MyCrossOverFcnConstraint(soldier(dam),flag,Dim,CrossType,Eval,par);
        else
            xy = rand(Dim, 1);
            TempXY = xy.* (ShrinkMinMax(:, 2) - ShrinkMinMax(:, 1)) + ShrinkMinMax(:, 1);
            soldier(dam).Position = TempXY;
            soldier(dam).Fault = 0;
        end


        for j = 1:Dim
            if soldier(dam).Position(j)<ShrinkMinMax(j,1)
                soldier(dam).Position(j)=ShrinkMinMax(j,1);
            end
            if soldier(Vic).Position(j)<ShrinkMinMax(j,1)
                soldier(Vic).Position(j)=ShrinkMinMax(j,1);
                vic_shrink = 1;
            end
            if soldier(dam).Position(j)>ShrinkMinMax(j,2)
                soldier(dam).Position(j)=ShrinkMinMax(j,2);
            end
            if soldier(Vic).Position(j)>ShrinkMinMax(j,2)
                soldier(Vic).Position(j)=ShrinkMinMax(j,2);
                vic_shrink = 1;
            end
        end

        [out]= Eval(soldier(dam).Position);
        soldier(dam).Cost = out.f;
        soldier(dam).g = out.g;
        soldier(dam).h = out.h;%
        soldier(dam).CV = Get_CV(par,soldier(dam));


        if vic_shrink == 1
            [out] = Eval(soldier(Vic).Position);
            soldier(Vic).Cost = out.f;
            soldier(Vic).g = out.g;
            soldier(Vic).h = out.h;%
            soldier(Vic).CV = Get_CV(par,soldier(Vic));
        end

        if Dominates(soldier(dam),flag)
            flag = soldier(dam);
        elseif Dominates(soldier(Vic),flag)
            flag = soldier(Vic);
        end
        %      Apply Mutation
        pm = 0.3;%(1-(iter-1)/(maxiter-1))^(1/mu);
        flag = MutationFcnConstraint(flag,mut,Dim,Eval,par,XMinMax,pm);
    end % end of pop loop

    tamp  = SelectLeaderFinal(rep,beta,soldier);
    if Dominates(tamp,flag) %&& tamp.CV==0
        flag = tamp;
    end

    soldier=DetermineDomination(soldier);
    rep = updateRep_by_single(rep,flag);
    rep = updateRep(rep,soldier);
    %     % Determine Domination of New Resository Members
    rep = DetermineDomination(rep);
    %     % Keep only Non-Dminated Memebrs in the Repository
    rep2 = rep(~[rep.IsDominated]);
    rep = rep2;
    % Update Grid
    Grid = CreateGrid(rep,nGrid,alpha);

    % Update Grid Indices
    for i=1:numel(rep)
        rep(i)=FindGridIndex(rep(i),Grid);
    end

    % Check if Repository is Full
    if numel(rep)>nRep

        Extra=numel(rep)-nRep;
        for e=1:Extra
            rep=DeleteOneRepMemebr3(rep,gamma);
        end
    end

    if showopen
        % Plot Costs
        figure(1);
        PlotCosts(soldier,rep);
        % Show Iteration Information
        disp(['Iteration ' num2str(iter) ': Number of Rep Members = ' num2str(numel(rep))]);
    end

    if NFE>=MaxNFE
        break;
    end
end% end of iter

tamp  = SelectLeaderFinal(rep,beta,soldier);
if Dominates(tamp,flag)
    flag = tamp;
end

if(length(rep) < nRep)
    complated_Rep = ComplateRep2(rep,soldier,nRep,nGrid,alpha,gamma);
else
    complated_Rep = rep;
end  

for d = 1:par.fn
    repPop(:,d) = arrayfun(@(complated_Rep) complated_Rep.Cost(d), complated_Rep);
    i=0;
end

HV_Score = HV(repPop,Func);

disp(strcat('Flag_Costs = ',num2str(flag.Cost)));
disp(strcat('HV_Score = ',num2str(HV_Score)));
disp(strcat('NFE = ',num2str(NFE)));
disp(strcat('flag CV = ',num2str(flag.CV)));
CVd = 0;
RepFr = 0;

for re = 1:length(complated_Rep)
    CVd = CVd + complated_Rep(re).CV;
end
if CVd == 0
    RepFr = 1;
end

CVd = CVd/nRep;
disp(strcat('CVd = ',num2str(CVd)));

Res.HV_Score = HV_Score;
Res.CVd = CVd;
Res.RepFr = RepFr;
Res.flag = flag;

end


