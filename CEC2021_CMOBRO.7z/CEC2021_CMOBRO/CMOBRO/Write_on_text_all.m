function [] = Write_on_text(Res,fileIdAll,i)


fprintf(fileIdAll,'\n');
fprintf(fileIdAll,'F_%d \n',i); 

fprintf(fileIdAll, '\t BestHv    = %.6f \n', Res.BestHv);
fprintf(fileIdAll, '\t BestCVd   = %.6f \n', Res.BestCVd);
fprintf(fileIdAll, '\t MeanHv    = %.6f \n', Res.MeanHv);
fprintf(fileIdAll, '\t MeanCVd   = %.6f \n', Res.MeanCVd);
fprintf(fileIdAll, '\t WorthHv   = %.6f \n', Res.WorthHv);
fprintf(fileIdAll, '\t WorthCVd  = %.6f \n', Res.WorthCVd);
fprintf(fileIdAll, '\t StdHv     = %.6f \n', Res.StdHv);
fprintf(fileIdAll, '\t stdCVd    = %.6f \n', Res.stdCVd);
fprintf(fileIdAll,'\t FR        = %d \n',Res.FR * 100);

%fprintf(fileIdAll,'\t MedianHv  = %d \n',sprintf('%.6f',Res.MedianHv)); 
%fprintf(fileIdAll,'\t MedianCVd = %d \n',sprintf('%.6f',Res.MedianCVd));
%fprintf(fileIdAll,'\t MeanNFE   = %d \n',Res.GNFE);
%fprintf(fileIdAll,'\t RunTime   = %d \n',Res.RunTime);

end


