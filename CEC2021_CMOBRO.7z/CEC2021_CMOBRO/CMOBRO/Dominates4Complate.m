function b=Dominates4Complate(x,y)
    b=0;
    if isstruct(x)
        x=x.Cost;
    end
    
    if isstruct(y)
        y=y.Cost;
    end
    
    b=all(x<=y) && any(x<y);
    %     b=all(x.Cost<=y.Cost) && any(x.Cost<y.Cost) && x.CV<=y.CV;
end