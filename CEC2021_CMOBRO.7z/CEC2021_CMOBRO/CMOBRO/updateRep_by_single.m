function rep = updateRep_by_single(rep,single_soldier)
    % Add non repative Particles to REPOSITORY
    flg = 0;
    for jj = 1:numel(rep)
        newPosition = single_soldier.Position;
        existPosition = rep(jj).Position;
        if(newPosition == existPosition)
            flg = 1;
            break;
        end
    end
    if(flg == 0)
        rep = [rep; single_soldier];
    end

end

