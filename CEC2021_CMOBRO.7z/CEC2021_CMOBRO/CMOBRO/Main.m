% Author and Developer: Dr Sait Alp & Dr. Taymaz Akan
% Constrained Multi-objective Battle Royale Optimizer
clear, close all, clc
addpath('..\RWMOPs');
addpath('..\HV');

% Set the display format to long
format long


%% Problem Definition
global NFE;
NFE = 0;
GNFE = 0;
%% CMOBRO Parameters

MaxFault = 6;
CrossType = 4;      % 1: (original Paper)

mut = 1;
nGrid = 20;            % Number of Grids per Dimension
alpha = 0.1;          % Inflation Rate

beta = 1;             % Leader Selection Pressure
gamma = 2;            % Deletion Selection Pressure
mu = 0.3;             % Mutation Rate

showopen = 0;       % show only first 2 dimension of the problem space

NumRun = 2;
AllTestFuncNum = 50;
%% Main Loop

mkdir('Results');
fileIdAll = fopen(['Results\','all','.txt'],'w');
FeasibleRate = zeros(1,AllTestFuncNum);
HV = zeros(NumRun,AllTestFuncNum);
CV = zeros(NumRun,AllTestFuncNum);
Fr = zeros(NumRun,AllTestFuncNum);

for i = 1:50  % Select functions to be evaluate
    par = Cal_par(i);             
    Func = i;
    [MaxNFE,N,maxiter,nRep] = Get_run_conditions(par);
    tic;
    for r = 1:NumRun
        disp(['Func ' num2str(Func) ':  Run: ' num2str(r) ' Start' ])
        Res(r) = MOBRO_Fun_4(N,maxiter,Func,MaxNFE,MaxFault,CrossType,nGrid,alpha,beta,gamma,nRep,mu,par,showopen,mut);         
        GNFE = GNFE + NFE;
        NFE = 0;
        HV(r,i) = Res(r).HV_Score;
        CV(r,i) = Res(r).CVd;
        Fr(r,i) = Res(r).RepFr;
        filename = 'CMOBRO.xlsx';
    end
    xlswrite(filename, HV, 'HV');
    xlswrite(filename, CV, 'CV');
    xlswrite(filename, Fr, 'Fr');
    
    RunTime = toc;
    HV_Score = arrayfun(@(Res) Res.HV_Score, Res);
    CVd = arrayfun(@(Res) Res.CVd, Res);
    FR = arrayfun(@(Res) Res.RepFr, Res);
    AllRes.BestHv = max(HV_Score);
    AllRes.BestCVd = min(CVd);    
    AllRes.MeanHv = mean(HV_Score);
    AllRes.MeanCVd = mean(CVd);
    AllRes.WorthHv = min(HV_Score);
    AllRes.WorthCVd = max(CVd);
    AllRes.StdHv = std(HV_Score);
    AllRes.stdCVd = std(CVd);
    countRunAllSolFeasible = sum(FR == 1);
    AllRes.FR = countRunAllSolFeasible/NumRun;
    FeasibleRate(1,i) = AllRes.FR;

    AllRes.MedianHv = median(HV_Score);
    AllRes.MedianCVd = median(CVd);
    xlswrite(filename, FeasibleRate, 'FeasibleRate');
    AllRes.RunTime = RunTime/NumRun;
    
    AllRes.GNFE = GNFE/NumRun;    
    GNFE = 0;
    
    Write_on_text_all(AllRes,fileIdAll,i);    
end
fclose(fileIdAll);