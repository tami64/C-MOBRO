function Mu_solution = MutationFcnConstraint(solution,mut,Dim,Eval,par,XMinMax,pm)
for m = 1:mut
    
    tmpSoldier.Position=Mutate(solution.Position,pm,XMinMax(:, 1),XMinMax(:, 2));
    out = Eval(tmpSoldier.Position);
    tmpSoldier.Cost = out.f;
    tmpSoldier.g = out.g;
    tmpSoldier.h = out.h;
    tmpSoldier.CV = Get_CV(par,out);
    tmpSoldier.vel = zeros(Dim,1);
    tmpSoldier.Fault  =  0;
    tmpSoldier.IsDominated=[];
    tmpSoldier.GridIndex=[];
    tmpSoldier.GridSubIndex=[];
    
    if(solution.CV == 0 && tmpSoldier.CV ~= 0)
        Mu_solution.Position = solution.Position;
        Mu_solution.Cost     = solution.Cost;
        Mu_solution.g        = solution.g;
        Mu_solution.h        = solution.h;
        Mu_solution.CV       = solution.CV;
        Mu_solution.vel      = solution.vel;
        Mu_solution.Fault    = 0;
        Mu_solution.IsDominated = solution.IsDominated;
        Mu_solution.GridIndex = solution.GridIndex;
        Mu_solution.GridSubIndex = solution.GridSubIndex;

    end

    if(solution.CV ~= 0 && tmpSoldier.CV == 0)
        Mu_solution.Position = tmpSoldier.Position;
        Mu_solution.Cost     = tmpSoldier.Cost;
        Mu_solution.g        = tmpSoldier.g;
        Mu_solution.h        = tmpSoldier.h;
        Mu_solution.CV       = tmpSoldier.CV;
        Mu_solution.vel      = tmpSoldier.vel;
        Mu_solution.Fault    = 0;
        Mu_solution.IsDominated = [];
        Mu_solution.GridIndex = [];
        Mu_solution.GridSubIndex = [];
    end

    if(solution.CV ~= 0 && tmpSoldier.CV ~= 0)
        if(tmpSoldier.CV <= solution.CV)
            Mu_solution.Position = tmpSoldier.Position;
            Mu_solution.Cost     = tmpSoldier.Cost;
            Mu_solution.g        = tmpSoldier.g;
            Mu_solution.h        = tmpSoldier.h;
            Mu_solution.CV       = tmpSoldier.CV;
            Mu_solution.vel      = tmpSoldier.vel;
            Mu_solution.Fault    = 0;
            Mu_solution.IsDominated = [];
            Mu_solution.GridIndex = [];
            Mu_solution.GridSubIndex = [];
        else
            Mu_solution.Position = solution.Position;
            Mu_solution.Cost     = solution.Cost;
            Mu_solution.g        = solution.g;
            Mu_solution.h        = solution.h;
            Mu_solution.CV       = solution.CV;
            Mu_solution.vel      = solution.vel;
            Mu_solution.Fault    = 0;
            Mu_solution.IsDominated = solution.IsDominated;
            Mu_solution.GridIndex = solution.GridIndex;
            Mu_solution.GridSubIndex = solution.GridSubIndex;

        end
    end

    if(solution.CV == 0 && tmpSoldier.CV == 0)
        if Dominates(solution,tmpSoldier)
            Mu_solution.Position = solution.Position;
            Mu_solution.Cost     = solution.Cost;
            Mu_solution.g        = solution.g;
            Mu_solution.h        = solution.h;
            Mu_solution.CV       = solution.CV;
            Mu_solution.vel      = solution.vel;
            Mu_solution.Fault    = 0;
            Mu_solution.IsDominated = solution.IsDominated;
            Mu_solution.GridIndex = solution.GridIndex;
            Mu_solution.GridSubIndex = solution.GridSubIndex;
        else
            Mu_solution.Position = tmpSoldier.Position;
            Mu_solution.Cost     = tmpSoldier.Cost;
            Mu_solution.g        = tmpSoldier.g;
            Mu_solution.h        = tmpSoldier.h;
            Mu_solution.CV       = tmpSoldier.CV;
            Mu_solution.vel      = tmpSoldier.vel;
            Mu_solution.Fault    = 0;
            Mu_solution.IsDominated = [];
            Mu_solution.GridIndex = [];
            Mu_solution.GridSubIndex = [];
        end
    end    
    % i = 0 ;
end

