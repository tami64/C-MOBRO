% Author and Developer: Dr. Taymaz Rahkar Farshi
% Battle Royale Optimization Algorithm (Continuous version)
% taymaz.farshi@gmail.com
% Istanbul 2020

function [ p q ] = edistance_n(i,soldier)
V = size(soldier);
for j = 1:V
    Dist(j) = sqrt(sum((soldier(i).Position - soldier(j).Position) .^ 2));
end
Dist(i) = inf;
[p q] = sort(Dist);
end

