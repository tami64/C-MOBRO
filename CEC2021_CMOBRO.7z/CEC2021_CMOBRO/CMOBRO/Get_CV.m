function [v] = Get_CV(par,soldier)
ep = 1e-4;
g = soldier.g;
h = soldier.h;

% PopCon = [g;abs(h)-1e-4];

v = 0;
for i = 1:par.g
%     try
    v = v + max(0,g(i));
%     catch
%        aa=0; 
%     end
end
for i = 1:par.h
    v = v + max(0,abs(h(i))-ep);
end


end

