function [MaxNFE,popsiz,iter,repSize] = Get_run_conditions(par)

M = par.fn;
D = par.n;
MaxNFE = 0;

if M==2 && D<=10
    MaxNFE = 20000;
    popsiz = 80;
    iter = 2500;
elseif M==2 && D>10
    MaxNFE = 80000;
    popsiz = 80;
    iter = 10000;
elseif M==3 && D<=10
    MaxNFE = 26250;
    popsiz = 105;
    iter = 2500;
elseif M==3 && D>10
    MaxNFE = 105000;
    popsiz = 105;
    iter = 10000;
elseif M==4 && D<=10
    MaxNFE = 35750;
    popsiz = 143;
    iter = 2500;
elseif M==4 && D>10
    MaxNFE = 143000;
    popsiz = 143;
    iter = 10000;
elseif M==5 && D<=10
    MaxNFE = 53000;
    popsiz = 212;
    iter = 2500;
elseif M==5 && D>10
    MaxNFE = 212000;
    popsiz = 212;
    iter = 10000;
end

repSize = max(M*30,100);% popsiz;%

end

