function dimStd = calStd(soldier,dim,nPop)
    temp = [];
    for i = 1:nPop
        temp = [temp; soldier(i).Position(dim)];
    end
    dimStd = std(temp);
end

