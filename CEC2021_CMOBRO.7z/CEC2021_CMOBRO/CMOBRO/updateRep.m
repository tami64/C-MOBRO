function rep = updateRep(rep,soldier)
    nonDomInx = find(~[soldier.IsDominated]);    
    % Add Non-Dominated(and non repative) Particles to REPOSITORY
    for ii= 1:numel(nonDomInx)        
        flg = 0;
        indx = nonDomInx(ii);
        for jj = 1:numel(rep)
            newPosition = soldier(indx).Position;
            existPosition = rep(jj).Position;
            if(newPosition == existPosition)
                flg = 1;
                break;
            end
        end
        if(flg == 0)
           rep = [rep; soldier(indx)]; 
        end
    end
    
end

