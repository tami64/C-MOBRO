function xnew=Mutate(x,pm,VarMin,VarMax)
 ulb = [VarMin VarMax];

nVar=numel(x);
j=randi([1 nVar]);

dx=pm*(VarMax(j)-VarMin(j));

lb=x(j)-dx;
if lb<VarMin(j)
    lb=VarMin(j);
end

ub=x(j)+dx;
if ub>VarMax(j)
    ub=VarMax(j);
end

if lb>ub
    lb=VarMin(j);
    ub=VarMax(j);
end

xnew=x;
data = unifrnd(lb,ub);
xnew(j)=data;

if sum(isnan(xnew))
    a = 10;
end
if sum(isnan(x))
    a = 10;
end

end